package com.example.interactive_face_demo;

public class FaceDetection {
    final static float FACE_MINIMUM_SCORE = .90f;
    private float mScore;
    private boolean mValidFace;
    private long mLabel;
}
